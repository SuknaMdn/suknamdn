<?php

namespace TomatoPHP\FilamentIcons\Components;

use Filament\Tables\Columns\TextColumn;

class IconColumn extends TextColumn
{
    protected string $view = 'filament-icons::icon-column';
}
