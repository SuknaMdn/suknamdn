---
name: Icons Picker & Provider
slug: 3x1io-tomato-icons
author_slug: 3x1io
categories: [developer-tool]
description: Picker & Table Column & Icons Provider for FilamentPHP
discord_url: 
docs_url: https://raw.githubusercontent.com/tomatophp/filament-icons/master/README.md
github_repository: tomatophp/filament-icons
has_dark_theme: true
has_translations: true
versions: [3]
publish_date: 2024-04-14
---
