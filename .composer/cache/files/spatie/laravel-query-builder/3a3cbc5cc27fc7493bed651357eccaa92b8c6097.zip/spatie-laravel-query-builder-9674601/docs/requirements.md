---
title: Requirements
weight: 3
---

The Query Builder package requires **PHP 8 or above** and **Laravel 9 or above**. 

We only support and maintain the latest version. If you do not meet the minimum requirements, you can opt to use an older version of the package.

