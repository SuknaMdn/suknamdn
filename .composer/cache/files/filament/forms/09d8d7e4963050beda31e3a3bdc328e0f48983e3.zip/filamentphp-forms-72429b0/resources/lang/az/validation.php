<?php

return [

    'distinct' => [
        'must_be_selected' => 'Ən azı bir :attribute sahəsi seçilməlidir.',
        'only_one_must_be_selected' => 'Yalnız bir :attribute sahəsi seçilməlidir',
    ],

];
