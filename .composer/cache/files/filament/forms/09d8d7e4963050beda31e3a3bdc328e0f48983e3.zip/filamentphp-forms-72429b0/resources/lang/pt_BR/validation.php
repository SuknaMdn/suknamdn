<?php

return [

    'distinct' => [
        'must_be_selected' => 'Pelo menos um campo :attribute deve ser selecionado.',
        'only_one_must_be_selected' => 'Apenas um campo :attribute deve ser selecionado.',
    ],

];
