<?php

return [

    'distinct' => [
        'must_be_selected' => 'Sekurang-kurangnya satu medan :attribute mesti dipilih.',
        'only_one_must_be_selected' => 'Hanya satu medan :attribute mesti dipilih.',
    ],

];
