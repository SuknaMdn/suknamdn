<?php

return [

    'distinct' => [
        'must_be_selected' => ' Має бути вибрано хоча б одне поле :attribute.',
        'only_one_must_be_selected' => 'Має бути вибрано тільки одне поле :attribute.',
    ],

];
