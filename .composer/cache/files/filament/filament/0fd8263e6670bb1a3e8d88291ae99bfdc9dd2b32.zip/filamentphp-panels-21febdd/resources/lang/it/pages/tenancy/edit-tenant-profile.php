<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Salva modifiche',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Salvato',
        ],

    ],

];
