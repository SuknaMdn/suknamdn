<?php

return [

    'title' => 'دروستکردنی :label',

    'breadcrumb' => 'دروستکردن',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'پاشگەزبوونەوە',
            ],

            'create' => [
                'label' => 'دروستکردن',
            ],

            'create_another' => [
                'label' => 'دروستکردن و تۆمارێکی تر',
            ],

        ],

    ],

    'notifications' => [

        'created' => [
            'title' => 'دروستکرا',
        ],

    ],

];
