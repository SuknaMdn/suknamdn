<?php

return [

    'body' => 'Tens canvis sense desar. Estàs segur que vols sortir d\'aquesta pàgina?',

];
