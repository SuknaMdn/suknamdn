<?php

return [

    'title' => 'Dashboard',

    'actions' => [

        'filter' => [

            'label' => 'Filter',

            'modal' => [

                'heading' => 'Filter',

                'actions' => [

                    'apply' => [

                        'label' => 'Übernehmen',

                    ],

                ],

            ],

        ],

    ],
];
