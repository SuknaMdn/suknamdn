<?php

return [

    'title' => 'მიმოხილვა',

    'actions' => [

        'filter' => [

            'label' => 'ფილტრი',

            'modal' => [

                'heading' => 'ფილტრი',

                'actions' => [

                    'apply' => [

                        'label' => 'შესრულება',

                    ],

                ],

            ],

        ],

    ],

];
