<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'დოკუმენტაცია',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
