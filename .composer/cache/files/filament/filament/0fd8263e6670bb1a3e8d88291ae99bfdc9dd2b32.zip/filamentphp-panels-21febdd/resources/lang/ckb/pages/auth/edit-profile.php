<?php

return [

    'label' => 'پڕۆفایل',

    'form' => [

        'email' => [
            'label' => 'ئیمەیڵ',
        ],

        'name' => [
            'label' => 'ناو',
        ],

        'password' => [
            'label' => 'وشەی نهێنی نوێ',
        ],

        'password_confirmation' => [
            'label' => 'دڵنیابوونەوەی وشەی نهێنی نوێ',
        ],

        'actions' => [

            'save' => [
                'label' => 'نوێکردنەوە',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'نوێکرایەوە',
        ],

    ],

    'actions' => [

        'cancel' => [
            'label' => 'گەڕانەوە',
        ],

    ],

];
