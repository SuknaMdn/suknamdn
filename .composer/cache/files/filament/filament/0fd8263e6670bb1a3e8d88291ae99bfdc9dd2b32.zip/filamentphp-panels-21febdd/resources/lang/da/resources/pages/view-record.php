<?php

return [

    'title' => 'Vis :label',

    'breadcrumb' => 'Vis',

    'content' => [

        'tab' => [
            'label' => 'Vis',
        ],

    ],

];
