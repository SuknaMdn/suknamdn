<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Guardar alterações',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Guardado',
        ],

    ],

];
