<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Guardar',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Guardado',
        ],

    ],

];
