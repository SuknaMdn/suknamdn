<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Kaydet',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Kaydedildi',
        ],

    ],

];
