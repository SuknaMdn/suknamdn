<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Lưu thay đổi',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Đã lưu',
        ],

    ],

];
