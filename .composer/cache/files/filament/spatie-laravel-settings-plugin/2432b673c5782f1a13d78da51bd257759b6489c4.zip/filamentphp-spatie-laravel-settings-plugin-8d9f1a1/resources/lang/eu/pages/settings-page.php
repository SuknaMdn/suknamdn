<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Gorde',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Gordeta',
        ],

    ],

];
