<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Պահպանել',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Պահպանվել է',
        ],

    ],

];
