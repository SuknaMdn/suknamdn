<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Änderungen speichern',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Gespeichert',
        ],

    ],

];
