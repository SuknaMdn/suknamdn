<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Salvare',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Salvat cu succes',
        ],

    ],

];
