<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Tallenna',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Tallennettu',
        ],

    ],

];
