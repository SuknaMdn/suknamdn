<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Зберегти',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Збережено',
        ],

    ],

];
