<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Uložiť zmeny',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Uložené',
        ],

    ],

];
