<?php

return [

    'messages' => [
        'uploading_file' => 'កំពុងបង្ហោះឯកសារ...',
    ],

];
