<?php

return [

    'messages' => [
        'copied' => 'Zkopírováno',
    ],

];
