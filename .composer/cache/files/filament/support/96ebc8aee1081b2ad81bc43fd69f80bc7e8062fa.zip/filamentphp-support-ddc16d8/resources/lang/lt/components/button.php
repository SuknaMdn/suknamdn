<?php

return [

    'messages' => [
        'uploading_file' => 'Įkeliamas failas...',
    ],

];
