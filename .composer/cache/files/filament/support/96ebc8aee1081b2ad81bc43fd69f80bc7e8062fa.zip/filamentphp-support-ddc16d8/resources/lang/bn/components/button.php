<?php

return [

    'messages' => [
        'uploading_file' => 'নথি আপলোড হচ্ছে...',
    ],

];
