<?php

return [

    'messages' => [
        'uploading_file' => 'Prenosim datoteku...',
    ],

];
