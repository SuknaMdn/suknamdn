<?php

return [

    'messages' => [
        'copied' => 'U kopjua',
    ],

];
