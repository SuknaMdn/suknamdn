<?php

return [

    'messages' => [
        'copied' => 'Kopyalandı',
    ],

];
