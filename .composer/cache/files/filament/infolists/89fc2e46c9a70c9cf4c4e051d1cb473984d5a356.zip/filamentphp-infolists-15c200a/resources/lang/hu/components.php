<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => ':count elemmel kevesebb mutatása',
                'expand_list' => ':count elemmel több mutatása',
            ],

            'more_list_items' => ':count és több',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Kulcs',
                ],

                'value' => [
                    'label' => 'Érték',
                ],

            ],

            'placeholder' => 'Nincs megjeleníthető elem',

        ],

    ],

];
