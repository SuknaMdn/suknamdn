<?php

return [

    'text_entry' => [
        'more_list_items' => 'وە :count ی زیاتر',
    ],

];
