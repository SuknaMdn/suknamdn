<?php

return [

    'trigger' => [
        'label' => 'ქმედება',
    ],

];
