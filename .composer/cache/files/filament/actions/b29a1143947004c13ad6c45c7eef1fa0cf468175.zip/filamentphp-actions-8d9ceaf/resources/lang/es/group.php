<?php

return [

    'trigger' => [
        'label' => 'Acciones',
    ],

];
