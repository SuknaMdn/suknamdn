<?php

return [

    'single' => [

        'label' => 'ភ្ជាប់',

        'modal' => [

            'heading' => 'ភ្ជាប់ :label',

            'fields' => [

                'record_id' => [
                    'label' => 'ទិន្នន័យ',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'ភ្ជាប់',
                ],

                'attach_another' => [
                    'label' => 'ភ្ជាប់ & ភ្ជាប់ឡើងវិញ',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'បានភ្ជាប់ជោគជ័យ',
            ],

        ],

    ],

];
