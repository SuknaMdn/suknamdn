<?php

return [

    'trigger' => [
        'label' => 'Գործողություններ',
    ],

];
