<?php

return [

    'single' => [

        'label' => 'Trvale smazat',

        'modal' => [

            'heading' => 'Trvale smazat :label',

            'actions' => [

                'delete' => [
                    'label' => 'Smazat',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Smazáno',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Trvale smazat vybrané',

        'modal' => [

            'heading' => 'Trvale smazat vybrané :label',

            'actions' => [

                'delete' => [
                    'label' => 'Smazat',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Smazáno',
            ],

        ],

    ],

];
