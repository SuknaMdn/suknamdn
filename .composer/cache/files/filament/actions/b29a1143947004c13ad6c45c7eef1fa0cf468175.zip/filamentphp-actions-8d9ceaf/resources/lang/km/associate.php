<?php

return [

    'single' => [

        'label' => 'សហការី',

        'modal' => [

            'heading' => 'សហការី :label',

            'fields' => [

                'record_id' => [
                    'label' => 'ទិន្នន័យ',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'សហការី',
                ],

                'associate_another' => [
                    'label' => 'សេពគប់ & សេពគប់អ្នកដទៃ',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'ពាក់ព័ន្ធ',
            ],

        ],

    ],

];
