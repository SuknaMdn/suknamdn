<?php

return [

    'single' => [

        'label' => '삭제',

        'modal' => [

            'heading' => '삭제 :label',

            'actions' => [

                'delete' => [
                    'label' => '삭제',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => '삭제 완료',
            ],

        ],

    ],

    'multiple' => [

        'label' => '선택한 항목 삭제',

        'modal' => [

            'heading' => ':label 선택한 항목 삭제',

            'actions' => [

                'delete' => [
                    'label' => '선택한 항목 삭제',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => '삭제 완료',
            ],

        ],

    ],

];
