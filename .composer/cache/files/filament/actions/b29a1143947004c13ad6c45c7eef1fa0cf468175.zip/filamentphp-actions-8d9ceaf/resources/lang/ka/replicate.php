<?php

return [

    'single' => [

        'label' => 'დუბლირება',

        'modal' => [

            'heading' => 'ადუბლირებთ :label',

            'actions' => [

                'replicate' => [
                    'label' => 'დუბლირება',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'დუბლირებულია',
            ],

        ],

    ],

];
