<?php

return [

    'single' => [

        'label' => 'Προβολή',

        'modal' => [

            'heading' => 'Προβολή :label',

            'actions' => [

                'close' => [
                    'label' => 'Άκυρο',
                ],

            ],

        ],

    ],

];
