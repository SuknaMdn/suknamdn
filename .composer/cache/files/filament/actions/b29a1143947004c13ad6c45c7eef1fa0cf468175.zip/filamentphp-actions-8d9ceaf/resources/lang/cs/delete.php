<?php

return [

    'single' => [

        'label' => 'Smazat',

        'modal' => [

            'heading' => 'Smazat :label',

            'actions' => [

                'delete' => [
                    'label' => 'Smazat',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Smazáno',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Smazat vybrané',

        'modal' => [

            'heading' => 'Smazat vybrané :label',

            'actions' => [

                'delete' => [
                    'label' => 'Smazat vybrané',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Smazáno',
            ],

        ],

    ],

];
