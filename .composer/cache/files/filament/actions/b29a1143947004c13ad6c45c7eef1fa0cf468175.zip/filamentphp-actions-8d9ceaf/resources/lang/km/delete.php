<?php

return [

    'single' => [

        'label' => 'លុប',

        'modal' => [

            'heading' => 'លុប :label',

            'actions' => [

                'delete' => [
                    'label' => 'លុប',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'បានលុប',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'លុបចោលការជ្រើសរើស',

        'modal' => [

            'heading' => 'លុបចោលការជ្រើសរើស :label',

            'actions' => [

                'delete' => [
                    'label' => 'លុប',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'បានលុប',
            ],

        ],

    ],

];
