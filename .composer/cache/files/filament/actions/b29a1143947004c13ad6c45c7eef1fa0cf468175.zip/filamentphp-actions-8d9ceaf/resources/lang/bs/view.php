<?php

return [

    'single' => [

        'label' => 'Pregledajte',

        'modal' => [

            'heading' => 'Pregled :label',

            'actions' => [

                'close' => [
                    'label' => 'Zatvoriti',
                ],

            ],

        ],

    ],

];
