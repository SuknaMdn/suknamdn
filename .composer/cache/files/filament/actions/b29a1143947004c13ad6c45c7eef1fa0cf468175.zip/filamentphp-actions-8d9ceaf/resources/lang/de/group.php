<?php

return [

    'trigger' => [
        'label' => 'Aktionen',
    ],

];
